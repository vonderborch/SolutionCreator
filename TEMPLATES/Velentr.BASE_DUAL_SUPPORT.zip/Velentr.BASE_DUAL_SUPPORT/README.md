# Velentr.BASE
A library

# Installation
There are nuget packages available for Monogame and FNA:
- Monogame [![NuGet version (Velentr.BASE.Monogame)](https://img.shields.io/nuget/v/Velentr.BASE.Monogame.svg?style=flat-square)](https://www.nuget.org/packages/Velentr.BASE.Monogame/): [Velentr.BASE.Monogame](https://www.nuget.org/packages/Velentr.BASE.Monogame/)
- FNA [![NuGet version (Velentr.BASE.FNA)](https://img.shields.io/nuget/v/Velentr.BASE.FNA.svg?style=flat-square)](https://www.nuget.org/packages/Velentr.BASE.FNA/): [Velentr.BASE.FNA](https://www.nuget.org/packages/Velentr.BASE.FNA/)

# Future Plans
See list of issues under the Milestones: https://github.com/vonderborch/Velentr.BASE/milestones